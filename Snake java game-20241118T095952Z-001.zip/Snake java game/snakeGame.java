import java.util.Random;
import java.util.Scanner;

public class SnakeGame {
    static final int WIDTH = 20;
    static final int HEIGHT = 10;
    static final char EMPTY = '.';
    static final char SNAKE = 'O';
    static final char FOOD = '*';
    static char[][] board = new char[HEIGHT][WIDTH];
    static int[] snakeX = new int[WIDTH * HEIGHT];
    static int[] snakeY = new int[WIDTH * HEIGHT];
    static int snakeLength = 1;
    static int foodX, foodY;
    static boolean gameOver = false;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();

        // Initialize game board
        initializeBoard();
        spawnFood(rand);

        // Game loop
        while (!gameOver) {
            printBoard();
            System.out.println("Use WASD to move the snake: ");
            char move = sc.next().charAt(0);
            moveSnake(move);
            checkCollision();
            if (!gameOver) {
                checkFoodCollision();
            }
        }
        System.out.println("Game Over!");
    }

    static void initializeBoard() {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                board[i][j] = EMPTY;
            }
        }
        snakeX[0] = WIDTH / 2; // Starting x position
        snakeY[0] = HEIGHT / 2; // Starting y position
        board[snakeY[0]][snakeX[0]] = SNAKE;
    }

    static void printBoard() {
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                System.out.print(board[i][j]);
            }
            System.out.println();
        }
    }

    static void moveSnake(char move) {
        // Get current head position
        int headX = snakeX[0];
        int headY = snakeY[0];

        // Move snake based on input
        switch (move) {
            case 'w': headY--; break; // Up
            case 'a': headX--; break; // Left
            case 's': headY++; break; // Down
            case 'd': headX++; break; // Right
            default:
                System.out.println("Invalid input!");
                return;
        }

        // Shift the snake body
        for (int i = snakeLength - 1; i > 0; i--) {
            snakeX[i] = snakeX[i - 1];
            snakeY[i] = snakeY[i - 1];
        }

        // Update head position
        snakeX[0] = headX;
        snakeY[0] = headY;

        // Check if snake moves out of bounds
        if (headX < 0 || headX >= WIDTH || headY < 0 || headY >= HEIGHT) {
            gameOver = true;
            return;
        }

        updateBoard();
    }

    static void updateBoard() {
        // Reset the board to empty
        for (int i = 0; i < HEIGHT; i++) {
            for (int j = 0; j < WIDTH; j++) {
                board[i][j] = EMPTY;
            }
        }

        // Place the snake
        for (int i = 0; i < snakeLength; i++) {
            board[snakeY[i]][snakeX[i]] = SNAKE;
        }
        board[foodY][foodX] = FOOD;
    }

    static void checkCollision() {
        // Check if the snake collides with itself
        for (int i = 1; i < snakeLength; i++) {
            if (snakeX[0] == snakeX[i] && snakeY[0] == snakeY[i]) {
                gameOver = true;
                return;
            }
        }
    }

    static void checkFoodCollision() {
        if (snakeX[0] == foodX && snakeY[0] == foodY) {
            snakeLength++;
            spawnFood(new Random());
        }
    }

    static void spawnFood(Random rand) {
        foodX = rand.nextInt(WIDTH);
        foodY = rand.nextInt(HEIGHT);

        // Ensure food doesn't spawn on the snake
        for (int i = 0; i < snakeLength; i++) {
            if (snakeX[i] == foodX && snakeY[i] == foodY) {
                spawnFood(rand);
                return;
            }
        }
    }
}
